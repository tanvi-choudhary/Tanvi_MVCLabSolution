package com.gl.student.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.gl.student.entity.Student;

@Service
public interface StudentService {

	public void save(Student student);
	
	public List<Student> updateStudent(Student student);

	public boolean deleteById(int studentId);

	public Student getStudentById(int studentId);

	public List<Student> findAll();

}
