package com.gl.student.controller;

import com.gl.student.service.*;
import com.gl.student.entity.Student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@RequestMapping("/welcome")
	public String getWelcomePage() {
		return "add-student";
	}

	@RequestMapping("/add-student")
	public String addStudent(@ModelAttribute("student") Student student) {
		studentService.save(student);
		
		return "sucess";
	}

	@RequestMapping("/showStudent")
	public String showAllStudent(ModelMap map) {
		 List<Student> AllStudent = studentService.findAll();
		 map.addAttribute("student", AllStudent);
		 return "printall-student";
		 
	}
	
	@RequestMapping("/delete-student")
	public String deleteStudent(@RequestParam("studentId") int studentId, ModelMap map) {
		studentService.deleteById(studentId);

		
		map.addAttribute("DeleteMsg","Student with id " +studentId+ " deleted succesfully");
		return "delete-success";
	}
	
	//For add and update person both
		@RequestMapping("/update-student") 
		public String updateAllStudent(@ModelAttribute("student") Student student,ModelMap map) {
			List<Student> AllStudent = studentService.updateStudent(student);
			map.addAttribute("student", AllStudent);
			return "update-sucess";
			
		}
	}
	