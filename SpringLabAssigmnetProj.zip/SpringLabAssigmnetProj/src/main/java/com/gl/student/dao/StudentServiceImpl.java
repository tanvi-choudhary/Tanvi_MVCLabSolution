package com.gl.student.dao;
import com.gl.student.entity.Student;
import com.gl.student.service.*;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StudentServiceImpl implements StudentService 
{
	
	private SessionFactory sessionFactory;

	private Session session;

	@Autowired
	public StudentServiceImpl(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;

		try {
			session = this.sessionFactory.getCurrentSession();
		} catch (HibernateException exception) {
			session = sessionFactory.openSession();
		}
	}

	@Override
	public void save(Student student) {

		Transaction txn = session.beginTransaction();
		session.save(student);
		txn.commit();
		
		System.out.println("Student saved with StudentId:" + student.getStudentId());
	}

	@Override
	public List<Student> updateStudent(Student s) {
		
		return session.createQuery("update Student set name="+s.getname()+", department="+s.getdepartment()+",country="+s.getcountry()+" where id="+s.getStudentId(), Student.class).getResultList();
	}
	
	@Override
	public boolean deleteById(int studentId) {
		Student student = getStudentById(studentId);
		Transaction transaction = session.beginTransaction();
		session.delete(student);
		transaction.commit();
		
		return true;
	}
	
	@Override
	public Student getStudentById(int studentId) {
		return session.find(Student.class, studentId);
	}
	
	@Override
	public List<Student> findAll() {
		return session.createQuery("from Student", Student.class).getResultList();
	}
	
	

	

	


}