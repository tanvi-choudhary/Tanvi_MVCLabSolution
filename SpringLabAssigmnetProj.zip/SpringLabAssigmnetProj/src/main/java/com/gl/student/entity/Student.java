package com.gl.student.entity;

import javax.persistence.*;
@Entity
@Table (name = "student")

	public class Student 
	{


		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int studentId;
		private String name;
		private String department;
		private String country;
		
		public Student() {
		}

		public Student(String name, String department, String country) {
			super();
			this.name = name;
			this.department = department;
			this.country = country;
		}

		public int getStudentId() {
			return studentId;
		}

		public void setStudentId(int studentId) {
			this.studentId = studentId;
		}
		
		public String getname() {
			return name;
		}

		public void setname(String name) {
			this.name = name;
		}


		public String getdepartment() {
			return department;
		}

		public void setdepartment(String department) {
			this.department = department;
		}

		public String getcountry() {
			return country;
		}

		public void setcountry(String country) {
			this.country = country;
		}


		@Override
		public String toString() {
			return "Student [studentId=" + studentId + ", name=" + name + ", department=" + department+ ", country=" + country + "]";
		}
		

	}


